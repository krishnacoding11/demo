import 'package:flutter/material.dart';
const Color whiteFFFFFFColor = Color(0xFFFFFFFF);
const Color black00 = Colors.black;
const Color black101010Color = Color(0xFF101010);
const Color color839BFE = Color(0xff839BFE);