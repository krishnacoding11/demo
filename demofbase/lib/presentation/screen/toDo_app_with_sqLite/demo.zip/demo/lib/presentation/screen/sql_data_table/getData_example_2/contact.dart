class Contact {
  String name;
  String contact;
  Contact({required this.name, required this.contact});
}
