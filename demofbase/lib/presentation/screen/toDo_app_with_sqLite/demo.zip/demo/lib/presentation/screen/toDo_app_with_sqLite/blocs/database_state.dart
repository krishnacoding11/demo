abstract class DatabaseState {}

class InitDatabaseState extends DatabaseState {}
class LoadDatabaseState extends DatabaseState {}