class Todo {
  final int id;
  final String text;

  Todo(this.id, this.text);
}