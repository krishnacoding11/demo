import 'package:get/get.dart';

class QRScannerController extends GetxController {
  @override
  void onInit() {
    // TODO: implement onInit
    super.onInit();
  }
}
